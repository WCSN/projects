#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include "serialport.h"

namespace Ui
{
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void Print(QString data);

signals:
    void writeData(QByteArray data);

private slots:

    void checkCustomBaudRatePolicy(int idx);

    void on_cEnterText_returnPressed();
    void on_Connect();

private:
    Ui::MainWindow *ui;
    wSerialPort *mPort;

    void shearchSerialPorts(void);
};

#endif // MAINWINDOW_H
