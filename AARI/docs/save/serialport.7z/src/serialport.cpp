#include "mainwindow.h"
#include "serialport.h"


wSerialPort::wSerialPort(QObject *parent, MainWindow *MW, Ui_MainWindow *UI):
    QObject(parent),
    mw(MW),
    ui(UI),
    mSerialPort(new QSerialPort)
{
}

wSerialPort::~wSerialPort()
{
    emit finished_Port();
}

void wSerialPort :: process_Port()
{
    connect(mSerialPort,SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(handleError(QSerialPort::SerialPortError)));
    connect(mSerialPort, SIGNAL(readyRead()),this,SLOT(ReadInPort()));
}

void wSerialPort::setSerialPortSettings(QString name, int baudrate,int dataBits, int parity,int stopBits, int flowControl)
{
    mName = name;
    mBaudRate = (QSerialPort::BaudRate) baudrate;
    mDataBits = (QSerialPort::DataBits) dataBits;
    mParity = (QSerialPort::Parity) parity;
    mStopBits = (QSerialPort::StopBits) stopBits;
    mFlowControl = (QSerialPort::FlowControl) flowControl;
}

void wSerialPort::ConnectPort(void)
{
    mSerialPort->setPortName(mName);

    if (mSerialPort->open(QIODevice::ReadWrite))
    {
        if (mSerialPort->setBaudRate(mBaudRate)
                && mSerialPort->setDataBits(mDataBits)
                && mSerialPort->setParity(mParity)
                && mSerialPort->setStopBits(mStopBits)
                && mSerialPort->setFlowControl(mFlowControl))
        {
            if (mSerialPort->isOpen())
            {
                mw->Print((mName+ " >> Открыт!\r").toLocal8Bit());
            }
        }
        else
        {
            mSerialPort->close();
            mw->Print(mSerialPort->errorString().toLocal8Bit());
        }
    }
    else
    {
        mSerialPort->close();
        mw->Print(mSerialPort->errorString().toLocal8Bit());
    }
}

void wSerialPort::handleError(QSerialPort::SerialPortError error)//
{
    if ( (mSerialPort->isOpen()) && (error == QSerialPort::ResourceError))
    {
        DisconnectPort();
    }
}

void  wSerialPort::DisconnectPort()
{
    if(mSerialPort->isOpen())
        mSerialPort->close();
}

void wSerialPort::WriteToPort(QByteArray data)
{
    if(mSerialPort->isOpen())
    {
        mSerialPort->write(data);
    }
}
//
void wSerialPort::ReadInPort()
{
    QByteArray data;

    data.append(mSerialPort->readAll());
    mw->Print(data);
}

