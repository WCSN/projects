#ifndef SERIALPORT_H
#define SERIALPORT_H

#include "ui_mainwindow.h"
#include <QObject>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

class MainWindow;

class wSerialPort : public QObject
{
    Q_OBJECT

private:
    MainWindow *mw = nullptr;
    Ui_MainWindow *ui = nullptr;

    QString mName;
    qint32 mBaudRate;
    QSerialPort::DataBits mDataBits;
    QSerialPort::Parity mParity;
    QSerialPort::StopBits mStopBits;
    QSerialPort::FlowControl mFlowControl;

public:
    explicit wSerialPort(QObject *parent = nullptr, MainWindow *mw = nullptr, Ui_MainWindow *UI = nullptr);
    ~wSerialPort();

    QSerialPort *mSerialPort;
    void setSerialPortSettings(QString name, int baudrate, int DataBits, int Parity, int StopBits, int FlowControl);

signals:
    void finished_Port(); //
    void error_(QString err);
    void outPort(QString data);

public slots:
    void DisconnectPort();
    void ConnectPort(void);
    void process_Port();
    void WriteToPort(QByteArray data);
    void ReadInPort();

private slots:
    void handleError(QSerialPort::SerialPortError error);//
};

#endif // SERIALPORT_H
