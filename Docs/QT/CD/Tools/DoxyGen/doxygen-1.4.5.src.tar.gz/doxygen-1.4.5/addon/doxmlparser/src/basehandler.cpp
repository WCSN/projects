#include "basehandler.h"

QXmlLocator * LocatorContainer::s_theLocator=0;
